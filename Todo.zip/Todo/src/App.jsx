import AddToDo from "./components/addToDo";
// import ToDo1 from "./components/to_do_1";
// import ToDo2 from "./components/to_do_2";
import "./App.css";
import TodoItems from "./components/todoItems";
import { useState } from "react";
import WelcomeMessage from "./components/WelcomeMessage";

function App() {

  const [todoItems, setToDoItems] = useState([]);

  const handleNewItem = (itemName, itemDueDate) => {

    // console.log(`New Item Added: ${itemName} & Date:${itemDueDate}`);

    //1
    // const newTodoItems = [
    //   ...todoItems,
    //   { name: itemName, dueDate: itemDueDate },
    //   //'...' is called spread operators
    // ];
    // setToDoItems(newTodoItems);

    //2
    //   setToDoItems((currValue) => {
    //     const newTodoItems = [
    //       ...currValue,
    //       { name: itemName, dueDate: itemDueDate },
    //     ]
    //     return newTodoItems;
    //   })
    // }

    //3
    setToDoItems((currValue) =>
      [
        ...currValue,
        { name: itemName, dueDate: itemDueDate },
      ]);
  }

  const handleDeleteItem = (todoItemName) => {
    const newTodoItems = todoItems.filter((item) => item.name !== todoItemName);
    setToDoItems(newTodoItems);
  }

  return (
    <center className="todo-container"><h1>To-Do App</h1>
      <AddToDo onNewItem={handleNewItem}></AddToDo>
      {todoItems.length == 0 && <WelcomeMessage ></WelcomeMessage>}
      <TodoItems onTodoItems={todoItems} onDeleteClick={handleDeleteItem} ></TodoItems>
    </center >
  )
}

export default App