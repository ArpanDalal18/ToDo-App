function ToDo2() {
  let todoName = "Vegetable:";
  let todoDate = "15-12-12";

  return (
    <div class="row kg-row">
      <div className="col-6"> {todoName}
      </div>
      <div className="col-4"> {todoDate}
      </div>
      <div className="col-2">
        <button type="button" class="btn btn-danger kg-button">Delete</button></div>
    </div>
  );
}

export default ToDo2;