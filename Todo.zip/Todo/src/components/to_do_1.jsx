function ToDo1() {
  let todoName = "Milk";
  let todoDate = "10-12-22";


  return (
    <div class="row kg-row">
      <div className="col-6">
        {todoName}</div>
      <div className="col-4">
        {todoDate}</div>
      <div className="col-2">
        <button type="button" class="btn btn-danger kg-button">Delete</button></div>
    </div>
  );
}

export default ToDo1;