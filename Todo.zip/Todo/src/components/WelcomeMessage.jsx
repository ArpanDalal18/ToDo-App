import styles from "./WelcomeMessage.module.css";
const WelcomeMessage = () => {
  return <p className={styles.welcome}> Enjoy Your day.</p>
}

export default WelcomeMessage;